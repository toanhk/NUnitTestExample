﻿namespace NUnitTestExample
{
    public class CustomerController
    {
        public ActionResullt GetCustomer(int id)
        {
            if (id == 0)
            {
                return new NotFound();
            }

            return new Ok();
        }
    }

    public class Ok:ActionResullt { }
    public class NotFound:ActionResullt { }
    public class ActionResullt { }
}
