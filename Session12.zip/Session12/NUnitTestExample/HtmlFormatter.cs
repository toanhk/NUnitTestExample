﻿namespace NUnitTestExample
{
    public class HtmlFormatter
    {
        public string FormatAsBold(string context)
        {
            return $"<strong>{context}</strong>";
        }

    }
}
