﻿namespace NUnitTestExample
{
    public class User
    {
        public bool IsAdmin { get; set; }
    }
}