﻿namespace NUnitTestExample
{
    public class Math
    {
        public int Max(int a, int b)
        {
            return a > b ? a : b;
        }

        public int Max(int a, int b, int c)
        {
            int max = a;

            if (max < b)  max = b; 

            if (max < c) max = c;

            return max;
        }

        public List<int> GetOddNumbers(int limit)
        {
            List<int> numbers = new List<int>();

            for (int i = 1; i <= limit; i++)
            {
                if (i % 2 != 0)
                {
                    numbers.Add(i);
                }
            }

            return numbers;
        }

        public int Divide(int a,int b)
        {
            if (b == 0) throw new DivideByZeroException("Khong chia duoc cho 0");

            return a / b;
        }
    }
}
