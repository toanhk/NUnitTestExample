﻿namespace NUnitTestExample
{
    public class Reservation
    {
        public User MadeBy { get; set; }

        public bool CanBeCancelledBy(User user)
        {
            ////Node 1
            //if (user.IsAdmin)
            //{
            //    //Node 2
            //    return true;
            //}

            ////Node 3
            //if (user == MadeBy)
            //{
            //    //Node 4
            //    return true;
            //}

            //Node 5
            //return false;

            //Node 6
            //Ket thuc

            //Review Code laan 1 (Refactor code)
            //if (user.IsAdmin || user == MadeBy)
            //    return true;

            //return false;

            //refactor code 2

            return user.IsAdmin || user == MadeBy;
        }
    }
}
