﻿namespace NUnitTestExample.Tests
{
    public class MathTest
    {
        Math math;

        [SetUp]
        public void Setup()
        {
            math = new Math();
        }

        [Test]
        public void Max_FirstArgumentGreaterThan_ReturnFirstArgument()
        {
            var result = math.Max(2, 1);

            Assert.That(result, Is.EqualTo(2));
        }

        [Test]
        public void Max_SecondArgumentGreaterThan_ReturnSecondArgument()
        {
            var result = math.Max(1, 2);

            Assert.That(result, Is.EqualTo(2));
        }

        [Test]
        public void Max_ArgumentAreEqual_ReturnTheSameArgument()
        {
            var result = math.Max(2, 2);

            Assert.That(result, Is.EqualTo(2));
        }

        [Test]
        public void MaxHas3Parameters_FirstArgumentGreaterThan_ReturnFirstArgument()
        {
            var result = math.Max(3, 2, 1);

            Assert.That(result, Is.EqualTo(3));
        }

        [Test]
        public void MaxHas3Parameters_SecondArgumentGreaterThan_ReturnSecondArgument()
        {
            var result = math.Max(1, 3, 2);

            Assert.That(result, Is.EqualTo(3));
        }

        [Test]
        public void MaxHas3Parameters_ThirdArgumentGreaterThan_ReturnThirdArgument()
        {
            var result = math.Max(1, 2, 3);

            Assert.That(result, Is.EqualTo(3));
        }
        [Test]
        public void MaxHas3Parameters_ArgumentAreEqual_ReturnTheSameArgument()
        {
            var result = math.Max(2, 2, 2);

            Assert.That(result, Is.EqualTo(2));
        }

        [Test]
        [TestCase(3, 2, 1, 3)]
        [TestCase(3, 1, 2, 3)]
        [TestCase(1, 3, 2, 3)]
        [TestCase(2, 3, 1, 3)]
        [TestCase(1, 2, 3, 3)]
        [TestCase(2, 1, 3, 3)]
        [TestCase(3, 3, 3, 3)]
        public void MaxHas3Parameter_WhenCalled_ReturnTheGreatestArgument(int a, int b, int c, int expected)
        {
            var result = math.Max(a, b, c);

            Assert.That(result, Is.EqualTo(expected));
        }

        [Test]
        public void GetOddNumbers_WhenCalled_ReturnsOddNumbersToLimit()
        {
            var result = math.GetOddNumbers(5);

            var expected = new List<int> { 1, 3, 5 };

            Assert.That(result,Is.EquivalentTo(expected));
            Assert.That(result, Is.EqualTo(expected));
            Assert.That(result, Does.Contain(1));
            Assert.That(result, Does.Contain(3));
            Assert.That(result, Does.Contain(5));
        }

        [Test]
        public void Divide_DivisorIsZero_ReturnsThrowException()
        {
            Assert.That(()=>math.Divide(1,0),Throws.TypeOf<DivideByZeroException>());
        }
    }
}
