namespace NUnitTestExample.Tests
{
    public class ReservationTest
    {
        Reservation reservation;

        [SetUp]
        public void Setup()
        {
            reservation = new Reservation();
        }

        [Test]
        public void CanBeCancelledBy_CancelledByAdmin_ReturnTrue()
        {
            var result = reservation.CanBeCancelledBy(new User() { IsAdmin = true });

            Assert.IsTrue(result);
        }

        [Test]
        public void CanBeCancelledBy_SameUserCancelling_ReturnTrue()
        {
            var user=new User();

            reservation.MadeBy = user;
            
            var result = reservation.CanBeCancelledBy(user);

            Assert.IsTrue(result);
        }

        [Test]
        public void CanBeCancelledBy_AnotherUserCancelling_ReturnFalse()
        {
            reservation.MadeBy = new User();

            var result = reservation.CanBeCancelledBy(new User() { IsAdmin=false});

            Assert.IsFalse(result);
        }
    }
}